L'ENTRE 2 & LE MALRAUX — DOSSIER ÉDITABLE
=========================================

1. Ouvrir "index.html" dans un navigateur pour voir le site.
2. Modifier les textes et liens dans "index.html".
3. Modifier les couleurs, tailles et mise en page dans "style.css".
4. Modifier les interactions dans "script.js".
5. Remplacer une photo en conservant exactement son nom dans le dossier "photos".

SÉCURITÉ / ÉDITION
------------------
- Aucun mot de passe.
- Aucun fichier verrouillé.
- Aucun code minifié ou obfusqué.
- Aucun JavaScript externe.
- Aucune feuille CSS distante.
- Les photos sont locales.
- Les seuls services extérieurs encore utilisés sont les liens sociaux, Google Maps et les appels téléphoniques.

IMPORTANT — PHOTOS
------------------
Les photos disponibles ont été placées localement. Certaines cases de la galerie L'Entre 2 utilisent provisoirement les mêmes photos afin qu'aucune image ne soit cassée. Il suffit de remplacer ces fichiers par les photos définitives des restaurants en gardant leurs noms.

PUBLICATION
-----------
Envoyer ensemble index.html, style.css, script.js et le dossier photos/ à l'hébergement.
Ne publier jamais uniquement index.html.

CORRECTION NAVIGATION — VERSION 2
Les boutons L'adresse, La carte, Galerie et Infos utilisent maintenant une navigation JavaScript dédiée sans conflit avec window.scrollTo. Les sections des deux restaurants sont correctement distinguées.

CORRECTION V3 — NAVIGATION
Les liens L'adresse, La carte, Galerie et Infos utilisent maintenant des ancres HTML natives et uniques :
- Malraux : #about-malraux, #carte-malraux, #galerie-malraux, #infos-malraux
- L'Entre 2 : #about-entre2, #carte-entre2, #galerie-entre2, #infos-entre2
Ils continuent donc de fonctionner même si JavaScript est ralenti ou partiellement bloqué.

VERSION V4 — QR VISIBLE
- Le fichier qr-site.png est maintenant affiché dans une section dédiée sur les deux restaurants.
- Le QR est cliquable et ouvre https://restaurant-entre2malraux.fr/
- Le bouton « Partager le lien » utilise le partage natif du téléphone ou copie le lien.
