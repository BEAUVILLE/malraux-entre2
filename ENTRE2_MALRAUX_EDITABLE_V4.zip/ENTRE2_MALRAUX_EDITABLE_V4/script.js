'use strict';

const cur = document.getElementById('cur');
const cuf = document.getElementById('cuf');
const nav = document.getElementById('nav');
const drawer = document.getElementById('drawer');

if (cur && cuf) {
  document.addEventListener('mousemove', (event) => {
    cur.style.left = `${event.clientX}px`;
    cur.style.top = `${event.clientY}px`;
    window.setTimeout(() => {
      cuf.style.left = `${event.clientX}px`;
      cuf.style.top = `${event.clientY}px`;
    }, 80);
  });

  document.addEventListener('mouseleave', () => {
    cur.style.opacity = '0';
    cuf.style.opacity = '0';
  });

  document.addEventListener('mouseenter', () => {
    cur.style.opacity = '1';
    cuf.style.opacity = '1';
  });

  document.querySelectorAll('a, button').forEach((element) => {
    element.addEventListener('mouseenter', () => {
      cur.classList.add('hov');
      cuf.classList.add('hov');
    });
    element.addEventListener('mouseleave', () => {
      cur.classList.remove('hov');
      cuf.classList.remove('hov');
    });
  });
}

if (nav) {
  window.addEventListener(
    'scroll',
    () => nav.classList.toggle('solid', window.scrollY > 80),
    { passive: true }
  );
}

document.querySelectorAll('.land-half').forEach((element) => {
  element.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      element.click();
    }
  });
});

let currentSite = 'malraux';

const siteData = {
  malraux: {
    name: 'Le Malraux',
    subtitle: 'Restaurant Traditionnel · Sarlat',
    phoneHref: 'tel:+33642160657',
    phoneText: '06 42 16 06 57'
  },
  entre2: {
    name: "L'Entre 2",
    subtitle: 'Brasserie · Pizzeria · Sarlat',
    phoneHref: 'tel:+33673274427',
    phoneText: '06 73 27 44 27'
  }
};

function updateMainNavigation(which) {
  const anchors = {
    about: `#about-${which}`,
    carte: `#carte-${which}`,
    galerie: `#galerie-${which}`,
    infos: `#infos-${which}`
  };

  document.querySelectorAll('#nav [data-section], #drawer [data-section]').forEach((link) => {
    const target = anchors[link.dataset.section];
    if (target) link.setAttribute('href', target);
  });
}

function enterSite(which) {
  const landing = document.getElementById('landing');
  if (landing) landing.classList.add('gone');
  window.setTimeout(() => switchSite(which, true), 250);
}

function switchSite(which, force = false) {
  if (!siteData[which]) return;
  if (!force && which === currentSite) return;

  currentSite = which;
  document.body.className = which;

  document.querySelectorAll('.page').forEach((page) => page.classList.remove('active'));
  document.getElementById(`page-${which}`)?.classList.add('active');

  document.querySelectorAll('.sw-half').forEach((button) => {
    button.classList.remove('active');
    button.setAttribute('aria-pressed', 'false');
  });

  const activeSwitch = document.getElementById(`sw-${which}`);
  activeSwitch?.classList.add('active');
  activeSwitch?.setAttribute('aria-pressed', 'true');

  const selected = siteData[which];
  const navName = document.getElementById('nav-name');
  const navSub = document.getElementById('nav-sub');
  const telephone = document.getElementById('nav-tel');
  if (navName) navName.textContent = selected.name;
  if (navSub) navSub.textContent = selected.subtitle;
  if (telephone) {
    telephone.href = selected.phoneHref;
    telephone.textContent = selected.phoneText;
  }

  updateMainNavigation(which);
  drawer?.classList.remove('open');

  // Retire une ancienne ancre de l'autre restaurant puis revient en haut.
  try {
    if (location.hash) history.replaceState(null, '', location.href.split('#')[0]);
  } catch (error) {
    // L'ouverture locale du fichier peut limiter l'API History : sans conséquence.
  }
  window.scrollTo(0, 0);

  window.setTimeout(() => {
    document.querySelectorAll(`#page-${which} .reveal`).forEach((element) => {
      element.classList.add('in');
    });
  }, 80);
}

function ctab(id, button) {
  const panel = document.getElementById(id);
  if (!panel) return;
  const parent = panel.closest('.carte-s');
  if (!parent) return;

  parent.querySelectorAll('.cpanel').forEach((item) => item.classList.remove('on'));
  parent.querySelectorAll('.ctab').forEach((item) => {
    item.classList.remove('on');
    item.setAttribute('aria-selected', 'false');
  });

  panel.classList.add('on');
  button.classList.add('on');
  button.setAttribute('aria-selected', 'true');
}

const malrauxSwitch = document.getElementById('sw-malraux');
const entre2Switch = document.getElementById('sw-entre2');

malrauxSwitch?.addEventListener('click', () => {
  const landing = document.getElementById('landing');
  landing?.classList.contains('gone') ? switchSite('malraux') : enterSite('malraux');
});

entre2Switch?.addEventListener('click', () => {
  const landing = document.getElementById('landing');
  landing?.classList.contains('gone') ? switchSite('entre2') : enterSite('entre2');
});

// Les liens du menu sont désormais de vraies ancres HTML : aucun preventDefault.
document.querySelectorAll('[data-close-drawer="true"]').forEach((link) => {
  link.addEventListener('click', () => drawer?.classList.remove('open'));
});

updateMainNavigation('malraux');
malrauxSwitch?.classList.add('active');

const observer = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('in');
        observer.unobserve(entry.target);
      }
    });
  },
  { threshold: 0.08 }
);

document.querySelectorAll('.reveal').forEach((element) => observer.observe(element));

window.enterSite = enterSite;
window.switchSite = switchSite;
window.ctab = ctab;

async function shareOfficialSite(button) {
  const url = 'https://restaurant-entre2malraux.fr/';
  const data = {
    title: "L'Entre 2 & Le Malraux — Sarlat",
    text: "Découvrez L'Entre 2 et Le Malraux à Sarlat.",
    url
  };

  try {
    if (navigator.share) {
      await navigator.share(data);
      return;
    }
    await navigator.clipboard.writeText(url);
    const original = button?.textContent || 'Partager le lien';
    if (button) {
      button.textContent = 'Lien copié ✓';
      window.setTimeout(() => { button.textContent = original; }, 1800);
    }
  } catch (error) {
    if (error?.name !== 'AbortError') {
      window.prompt('Copiez ce lien :', url);
    }
  }
}

window.shareOfficialSite = shareOfficialSite;
